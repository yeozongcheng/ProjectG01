<?php
include "updateprofileadmin.php";

if(isSet($_POST['change']))
{
	UpdateProfileAdmin();
}

?>