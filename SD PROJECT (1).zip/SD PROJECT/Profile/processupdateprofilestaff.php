<?php
include "updateprofilestaff.php";

if(isSet($_POST['change']))
{
	UpdateProfileStaff();
}

?>